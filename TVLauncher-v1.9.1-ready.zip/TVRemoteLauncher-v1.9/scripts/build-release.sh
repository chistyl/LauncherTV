#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
./scripts/check-build-env.sh
if [[ -x ./gradlew && -f gradle/wrapper/gradle-wrapper.jar ]]; then
  ./gradlew --no-daemon :app:assembleRelease
else
  gradle --no-daemon :app:assembleRelease
fi
mkdir -p dist
cp app/build/outputs/apk/release/app-release.apk dist/TVLauncher-release-unsigned-or-signed.apk
echo "[SUCCESS] $ROOT/dist/TVLauncher-release-unsigned-or-signed.apk"
if [[ -z "${TVLAUNCHER_STORE_FILE:-}" ]]; then
  echo "[WARNING] No signing environment supplied; verify whether APK is signed before distribution."
fi
