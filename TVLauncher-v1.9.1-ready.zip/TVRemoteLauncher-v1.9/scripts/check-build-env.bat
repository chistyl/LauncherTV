@echo off
setlocal
cd /d "%~dp0.."
echo == Java ==
where java >nul 2>nul || (echo [ERROR] Java 17 is required.& exit /b 1)
for /f "tokens=3" %%V in ('java -version 2^>^&1 ^| findstr /i "version"') do set "JAVA_VER=%%~V"
echo Detected Java %JAVA_VER%
echo %JAVA_VER% | findstr /b /c:"\"17" >nul || (echo [ERROR] JDK 17 is required.& exit /b 1)

echo == Gradle ==
where gradle >nul 2>nul || (echo [ERROR] Gradle 8.9 is required. Open in Android Studio or install Gradle.& exit /b 1)
gradle --version

if "%ANDROID_SDK_ROOT%"=="" if "%ANDROID_HOME%"=="" (echo [ERROR] Set ANDROID_SDK_ROOT or ANDROID_HOME.& exit /b 1)
if not "%ANDROID_SDK_ROOT%"=="" (set "SDK=%ANDROID_SDK_ROOT%") else (set "SDK=%ANDROID_HOME%")
if not exist "%SDK%\platforms\android-35" (echo [ERROR] Android SDK Platform 35 is missing.& exit /b 1)
if not exist "%SDK%\build-tools" (echo [ERROR] Android SDK Build Tools are missing.& exit /b 1)
echo [OK] Build environment directories found.
endlocal
