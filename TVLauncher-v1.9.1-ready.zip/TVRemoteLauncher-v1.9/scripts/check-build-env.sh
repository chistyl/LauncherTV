#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "== Java =="
command -v java >/dev/null 2>&1 || { echo "[ERROR] JDK 17 is required." >&2; exit 1; }
JAVA_VERSION="$(java -XshowSettings:properties -version 2>&1 | awk -F'= ' '/java.specification.version/ {print $2; exit}')"
echo "Java specification version: ${JAVA_VERSION:-unknown}"
[[ "$JAVA_VERSION" == "17" ]] || { echo "[ERROR] Use JDK 17 (Android Gradle Plugin 8.7.3)." >&2; exit 1; }
echo "== Gradle =="
if [[ -x ./gradlew && -f gradle/wrapper/gradle-wrapper.jar ]]; then
  ./gradlew --version | head -n 8
elif command -v gradle >/dev/null 2>&1; then
  gradle --version | head -n 8
else
  echo "[ERROR] No usable Gradle launcher. This source archive intentionally does not fabricate a Wrapper JAR; open it in Android Studio or install Gradle 8.9." >&2
  exit 1
fi
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
[[ -n "$SDK" ]] || { echo "[ERROR] Set ANDROID_SDK_ROOT or ANDROID_HOME." >&2; exit 1; }
[[ -d "$SDK/platforms/android-35" ]] || { echo "[ERROR] Android SDK Platform 35 is missing: $SDK/platforms/android-35" >&2; exit 1; }
[[ -d "$SDK/build-tools" ]] || { echo "[ERROR] Android SDK Build Tools are missing." >&2; exit 1; }
found=false
for d in "$SDK"/build-tools/*; do [[ -x "$d/aapt" || -x "$d/aapt2" ]] && found=true; done
[[ "$found" == true ]] || { echo "[ERROR] No usable aapt/aapt2 found in SDK Build Tools." >&2; exit 1; }
echo "[OK] JDK 17, Gradle launcher, Android 35 platform and Build Tools found."
