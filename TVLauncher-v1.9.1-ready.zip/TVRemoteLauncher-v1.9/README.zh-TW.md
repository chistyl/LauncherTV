# TV Launcher v1.9.1

通用 Android TV / Google TV Launcher 原始碼。

## 本版調整
- 首頁 App 改為 16:9 橫向卡片；若電視 App 提供 banner artwork，優先使用 banner，否則以 App 圖示置中顯示。
- 大卡片模式每列 4 張，小卡片模式每列 6 張。
- 加入卡片圓角、深色底板、遙控器焦點外框及縮放動畫。
- 最低支援版本調整為 Android 8.0（API 26）。
- GitHub Actions 改用 Gradle 8.9 安裝流程，不再依賴封裝內缺少的 Gradle Wrapper JAR。

## 建置
在 GitHub Actions 的 Actions 頁面手動執行 **Android APK Build**，成功後下載 `TVLauncher-debug` artifact。

本專案仍需在實際 Android TV / Google TV 裝置上測試 HOME 預設、遙控器焦點移動、App 啟動及不同廠牌相容性。此原始碼封裝本身不代表 APK 已完成編譯。
